package com.kh.shop.product;

import org.apache.ibatis.annotations.Select;

public interface ProductMapper {

    @Select("SELECT * FROM PRODUCT WHERE PRODUCT_NO = ? AND TRIM(PRODUCT_SIZE) = ?")
    public ProductVo check(ProductVo vo);
}
