package com.kh.shop.product;

import lombok.Data;

@Data
public class ProductVo {
	private String product_Id;
	private String product_No;
	private String product_Cnt;
	private String product_Name;
	private String product_Price;
	private String product_Size;

}
