package com.kh.shop.product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private ProductMapper productMapper;

    public ProductVo check(ProductVo vo) {
        return productMapper.check(vo);
    }
}
