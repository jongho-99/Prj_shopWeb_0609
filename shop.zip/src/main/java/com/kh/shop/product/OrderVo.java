package com.kh.shop.product;

import lombok.Data;

@Data
public class OrderVo {
	
	private String order_No;
	private String order_Id;
	private String order_User;
	private String order_Cnt;
	private String order_Date;
	private String delivery_Address;
	private String delivery_Type;
	private String order_Size;

}
