package com.kh.shop.product;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;

@Controller
@RequestMapping("product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("prd01")
	protected void prd01() {
	}

	@GetMapping("buy")
	protected void buy() {

	}

	@PostMapping("buy")
	protected String buy(HttpSession ss, ProductVo vo) {

		if (ss.getAttribute("loginUser") == null) {
			ss.setAttribute("alertMsg", "로그인이 필요합니다.");
			return "/member/login";
		}

		//전 요청에서 받아온 데이터 2가지 넣어야함
		ss.setAttribute("delivery", delivery);
		ss.setAttribute("quantity", quantity);

		try {
			ProductVo productVo = productService.check(vo);

			if (productVo == null) {
				ss.setAttribute("alertMsg", "재고가 부족합니다");
				return "redirect:buy";
			}

			ss.setAttribute("productVo", productVo);
			return "redirect:buy2";

		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:error";
		}


	}
}
