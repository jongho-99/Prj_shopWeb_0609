package com.kh.shop.member;

import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberService {

	@Autowired
	private MemberMapper memberMapper;

	//회원가입
	public int join(MemberVo vo) {
		return memberMapper.join(vo);
	}
	//로그인
	public MemberVo login(MemberVo vo) {
		return memberMapper.login(vo);
	}

}
