package com.kh.shop.member;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface MemberMapper {
    @Insert("""
            INSERT INTO MEMBER(NO, USER_ID, USER_PWD, USER_NICK) VALUES(SEQ_MEMBER.NEXTVAL, #{userId}, #{userPwd}, #{userNick})
            """)
    int join(MemberVo vo);

    @Select("""
            SELECT * FROM MEMBER WHERE USER_ID = #{userId} AND USER_PWD = #{userPwd} AND DEL_YN = 'N'
            """)
    MemberVo login(MemberVo vo);
}
