package com.kh.shop.home;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;

@Controller("/home")
public class HomeController {

	@GetMapping
	public void home() {

	}
}