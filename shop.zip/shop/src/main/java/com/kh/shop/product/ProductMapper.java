package com.kh.shop.product;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface ProductMapper {

    @Select("SELECT * FROM PRODUCT WHERE PRODUCT_NO = #{productId} AND TRIM(PRODUCT_SIZE) = #{productSize}")
    ProductVo check(ProductVo vo);


    @Insert("""
            INSERT INTO ORDER_HEADER (
            ORDER_NO,
            ORDER_ID,
            ORDER_USER,
            ORDER_CNT,
            ORDER_DATE,
            DELIVERY_ADDRESS,
            DELIVERY_TYPE,
            ORDER_SIZE) VALUES
            (SEQ_ORDER.NEXTVAL, #{orderId}, #{orderUser},#{orderCnt}, SYSDATE, #{deliveryAddress}, #{deliveryType}, #{orderSize})
            """)
    int insertOrder(OrderVo vo);

    @Update("""
            UPDATE PRODUCT SET
            PRODUCT_CNT = PRODUCT_CNT - #{orderCnt}
            WHERE PRODUCT_NO = #{orderId} AND PRODUCT_SIZE = #{orderSize}
            """)
    int updateOrder(OrderVo vo);

    @Select("SELECT * FROM PRODUCT WHERE PRODUCT_ID = #{productId}")
    ProductVo check_pre(ProductVo vo);
}
