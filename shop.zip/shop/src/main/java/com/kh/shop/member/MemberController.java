package com.kh.shop.member;


import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.beans.factory.annotation.Autowired;


import java.io.IOException;

@Controller
@RequestMapping("member")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @GetMapping("join")
    public void join(){

    }

    @PostMapping("join")
    protected String join(MemberVo vo, HttpSession ss) {

        try {
            int result  = memberService.join(vo);
            if(result != 1) {

                ss.setAttribute("alertMsg", "회원가입 실패입니다.");
                return "/member/join";
            }

            ss.setAttribute("alertMsg", "회원가입 완료되었습니다");
            return "redirect:login";

        } catch(Exception e) {
            e.printStackTrace();
            return "redirect:error";
        }

    }

    @GetMapping("login")
    protected void doGet() {

    }


    @PostMapping("login")
    protected String doPost(MemberVo vo, HttpSession ss)  {

        try {
            MemberVo memberVo = memberService.login(vo);
            if(memberVo == null) {

                ss.setAttribute("alertMsg", "[로그인 실패] 아이디 비밀번호를 확인해주세요");
                return "redirect:login";
            }

            ss.setAttribute("alertMsg", memberVo.getUserId() + "님 반갑습니다.");
            ss.setAttribute("loginUser", memberVo);

            return "redirect:/home";

        } catch(Exception e) {
            ss.setAttribute("alertMsg", "[로그인 실패] 아이디 비밀번호를 확인해주세요");
            e.printStackTrace();
            return "/member/login";
        }
    }

    @GetMapping("logout")
    protected String service(HttpSession ss) {

        ss.removeAttribute("loginUser");
        ss.setAttribute("alertMsg", "로그아웃되었습니다.");

        return "redirect:/home";

    }
}
