package com.kh.shop.product;

import com.kh.shop.member.MemberVo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import oracle.jdbc.proxy.annotation.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("p1")
	protected String p1(ProductVo vo, HttpServletRequest req,HttpSession ss) {

		ProductVo selectVo = productService.check_pre(vo);

		ss.setAttribute("productVo", selectVo);
		return "/product/p1";
	}


	@PostMapping("p1")
	protected String p1(HttpSession ss, HttpServletRequest req) {

		if (ss.getAttribute("loginUser") == null) {
			ss.setAttribute("alertMsg", "로그인이 필요합니다.");
			return "/member/login";
		}


		ss.setAttribute("delivery", req.getParameter("delivery"));
		ss.setAttribute("quantity", req.getParameter("quantity"));
		ss.setAttribute("no", req.getParameter("productNo"));
		ss.setAttribute("productSize", req.getParameter("productSize"));
		ProductVo vo = new ProductVo();

		vo.setProductId((String)ss.getAttribute("no"));
		vo.setProductCnt((String)ss.getAttribute("quantity"));
		vo.setProductSize((String)ss.getAttribute("productSize"));


		try {
			System.out.println(vo);
			ProductVo productVo = productService.check(vo, ss);

			if (ss.getAttribute("alertMsg") != null) {
				return "redirect:p1";
			}

			ss.setAttribute("productVo", productVo);
			return "redirect:payment";

		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:error";
		}


	}

	@GetMapping("p2")
	protected String p2(ProductVo vo, HttpServletRequest req,HttpSession ss) {

		ProductVo selectVo = productService.check_pre(vo);

		ss.setAttribute("productVo", selectVo);
		return "/product/p2";
	}


	@PostMapping("p2")
	protected String p2(HttpSession ss, HttpServletRequest req) {

		if (ss.getAttribute("loginUser") == null) {
			ss.setAttribute("alertMsg", "로그인이 필요합니다.");
			return "/member/login";
		}


		ss.setAttribute("delivery", req.getParameter("delivery"));
		ss.setAttribute("quantity", req.getParameter("quantity"));
		ss.setAttribute("no", req.getParameter("productNo"));
		ss.setAttribute("productSize", req.getParameter("productSize"));
		ProductVo vo = new ProductVo();

		vo.setProductId((String)ss.getAttribute("no"));
		vo.setProductCnt((String)ss.getAttribute("quantity"));
		vo.setProductSize((String)ss.getAttribute("productSize"));


		try {
			System.out.println(vo);
			ProductVo productVo = productService.check(vo, ss);

			if (ss.getAttribute("alertMsg") != null) {
				return "redirect:p2";
			}

			ss.setAttribute("productVo", productVo);
			return "redirect:payment";

		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:error";
		}


	}


	@GetMapping("payment")
	public void payment(){

	}

	@PostMapping("payment")
	public String payment(HttpSession ss, OrderVo vo) {

		ProductVo productVo = (ProductVo) ss.getAttribute("productVo");
		String deliveryType = (String) ss.getAttribute("delivery");
		String quantityStr = (String) ss.getAttribute("quantity");

		MemberVo loginUser = (MemberVo)ss.getAttribute("loginUser");

		vo.setOrderId(productVo.getProductNo());
		vo.setOrderUser(loginUser.getUserId());
		vo.setOrderCnt(quantityStr);
		vo.setDeliveryType(deliveryType);
		vo.setOrderSize(productVo.getProductSize());

		int result = 0;
		try {
			result = productService.insertOrder(vo);

		} catch (Exception e) {

			e.printStackTrace();
		}

		if (result == 1) {
			ss.setAttribute("alertMsg", "주문이 완료되었습니다.");
			return "redirect:/home";
		} else {
			ss.setAttribute("alertMsg", "주문 처리 실패. 다시 시도해주세요.");
			return "redirect:/product/payment";
		}

	}

	@GetMapping("cart")
	public String viewCart(HttpSession ss) {
		if (ss.getAttribute("loginUser") == null) {
			ss.setAttribute("alertMsg", "로그인이 필요합니다.");
			return "/member/login";
		}

		return "/product/cart";
	}

	@PostMapping("cart")
	public String cart(HttpSession ss) {

		if (ss.getAttribute("loginUser") == null) {
			ss.setAttribute("alertMsg", "로그인이 필요합니다.");
			return "/member/login";
		}


		List<ProductVo> cartList = (List<ProductVo>) ss.getAttribute("cartList");

		if (cartList == null) {
			cartList = new ArrayList<ProductVo>();
			ss.setAttribute("cartList", cartList);
		}

		ProductVo selectVo = (ProductVo)ss.getAttribute("productVo");
		System.out.println(selectVo);
		cartList.add(selectVo);

		ss.setAttribute("cartList", cartList);
		ss.setAttribute("alertMsg","장바구니에 물품을 담았습니다.");

		return "redirect:p1";
	}

}
