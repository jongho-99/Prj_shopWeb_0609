package com.kh.shop.product;

import lombok.Data;

@Data
public class OrderVo {
	
	private String orderNo;
	private String orderId;
	private String orderUser;
	private String orderCnt;
	private String orderDate;
	private String userPhone;
	private String deliveryAddress;
	private String deliveryType;
	private String orderSize;




}
