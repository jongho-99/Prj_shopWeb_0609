package com.kh.shop.product;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    @Autowired
    private ProductMapper productMapper;

    public ProductVo check(ProductVo vo, HttpSession ss) {

        ProductVo selectVo = productMapper.check(vo);

        if(Integer.parseInt(selectVo.getProductCnt()) >= Integer.parseInt(vo.getProductCnt())) {
            return productMapper.check(vo);
        } else {
            ss.setAttribute("alertMsg", "재고가 부족합니다.");
            return productMapper.check(vo);
        }
    }

    public int insertOrder(OrderVo vo) {
        int result = 0;
        if(productMapper.updateOrder(vo) == 1 && productMapper.insertOrder(vo)== 1)
            result = 1;

        return result;
    }

    public ProductVo check_pre(ProductVo vo) {
        return productMapper.check_pre(vo);
    }
}
