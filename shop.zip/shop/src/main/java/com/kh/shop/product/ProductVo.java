package com.kh.shop.product;

import lombok.Data;

@Data
public class ProductVo {
	private String productId;
	private String productNo;
	private String productCnt;
	private String productName;
	private String productPrice;
	private String productSize;

}
